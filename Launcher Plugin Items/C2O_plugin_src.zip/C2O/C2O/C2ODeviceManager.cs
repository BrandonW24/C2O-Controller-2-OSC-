﻿using MassiveLoopLauncher;
using MassiveLoopLauncher.DataBus.OSCMessages;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Shapes;
using Avalonia.Layout;
using Avalonia.Media;
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using C2O.Serialization;
using System.Text.Json;
using System.IO;
using SDL2;
using System.Net.Sockets;
using CoreOSC;
using CoreOSC.IO;
using System.Runtime.InteropServices;

namespace C2O
{
    public class MLC2OPlugin : IMLPlugin
    {
        [DllImport("user32.dll")]
        public static extern short GetAsyncKeyState(int vKey);

        public static ILauncherAPIVersion1? API { get; private set; }

        public string Name => "C2O Device Manager";
        public string Description => "Controller to OSC device manager plugin with Profile Support.";
        public string ID => "C2O-DM-Plugin-v1";

        private CancellationTokenSource? _cancellationTokenSource;
        private AppConfig _appConfig = new AppConfig();
        private string _currentProfileName = "Default";
        private bool _isUpdatingProfiles = false;

        // --- STREAMING STATE & SOCKETS ---
        private volatile bool _isStreaming = false;
        private UdpClient? _oscSender;

        // Hardware State
        private List<DeviceInfo> _activeDevices = new List<DeviceInfo>();
        private Dictionary<int, AxisConfig> _axisConfigs = new Dictionary<int, AxisConfig>();
        private Dictionary<int, ButtonConfig> _buttonConfigs = new Dictionary<int, ButtonConfig>();
        private Dictionary<int, HatConfig> _hatConfigs = new Dictionary<int, HatConfig>();
        private Dictionary<int, KeyConfig> _keyConfigs = new Dictionary<int, KeyConfig>();

        // Polling & Previews
        private ConcurrentDictionary<int, float> _prevAxes = new ConcurrentDictionary<int, float>();
        private ConcurrentDictionary<int, byte> _prevButtons = new ConcurrentDictionary<int, byte>();
        private ConcurrentDictionary<int, (int x, int y)> _prevHats = new ConcurrentDictionary<int, (int, int)>();
        private ConcurrentDictionary<int, bool> _prevKeys = new ConcurrentDictionary<int, bool>();
        private Dictionary<int, float> _axisEmaHistory = new Dictionary<int, float>();

        // UI References
        private StackPanel? _dynamicSettingsPanel;
        private StackPanel? _keyboardSettingsPanel;
        private ComboBox? _deviceDropdown;
        private ComboBox? _profileDropdown;
        private TextBox? _txtTargetIp;
        private TextBox? _txtTargetPort;
        private TextBox? _txtBaseAddress;
        private Button? _btnToggleStream;
        private Dictionary<int, ProgressBar> _axisPreviewBars = new Dictionary<int, ProgressBar>();
        private Dictionary<int, Ellipse> _buttonPreviewDots = new Dictionary<int, Ellipse>();
        private TextBox? _logArea;
        private volatile bool _isLoggingEnabled = true;
        private StackPanel? _mainUIStack;

        // Dynamic Watermark list
        private List<TextBox> _addressWatermarkBoxes = new List<TextBox>();

        // --- SHARED UI COLORS (Ported from MainWindow.xaml.cs) ---
        private SolidColorBrush _bgDark = new SolidColorBrush(Color.Parse("#2F353D"));
        private SolidColorBrush _inputBoxColor = new SolidColorBrush(Color.Parse("#717171"));
        private SolidColorBrush _labelColor = new SolidColorBrush(Color.Parse("#DFBB3F"));

        public async Task Initialize(ILauncherAPIVersion1 launcherAPI)
        {
            API = launcherAPI;

            try
            {
                Control settingsUI = BuildSettingsUI();
                API.AttachSettingsVisual(settingsUI);

                LoadConfig();

                SDL.SDL_Init(SDL.SDL_INIT_JOYSTICK | SDL.SDL_INIT_HAPTIC);
                RefreshDeviceList();

                _cancellationTokenSource = new CancellationTokenSource();
                Task.Run(() => HardwarePollingLoop(_cancellationTokenSource.Token));
                Task.Run(() => UIUpdateLoop(_cancellationTokenSource.Token));

                API.Log("C2O Plugin Initialized.", PluginLogType.Info);
            }
            catch (Exception ex)
            {
                API.LogException(ex);
            }

            await Task.CompletedTask;
        }

        public async Task Shutdown()
        {
            _cancellationTokenSource?.Cancel();
            SaveConfig();

            _oscSender?.Close();
            _oscSender?.Dispose();

            foreach (var device in _activeDevices)
            {
                if (device.Haptic != IntPtr.Zero) SDL.SDL_HapticClose(device.Haptic);
                if (device.Joystick != IntPtr.Zero) SDL.SDL_JoystickClose(device.Joystick);
            }
            SDL.SDL_Quit();

            API?.Log("C2O Plugin Shut Down.", PluginLogType.Info);
            await Task.CompletedTask;
        }

        // ==========================================
        // PROFILE MANAGEMENT & PERSISTENCE
        // ==========================================
        private void LoadConfig()
        {
            string json = API?.StorageGetValue<string>("C2O_AppConfig") ?? "";
            if (!string.IsNullOrEmpty(json))
            {
                try { _appConfig = JsonSerializer.Deserialize<AppConfig>(json) ?? new AppConfig(); }
                catch { _appConfig = new AppConfig(); }
            }

            if (_appConfig.Profiles.Count == 0) _appConfig.Profiles["Default"] = new ProfileData();
            _currentProfileName = _appConfig.ActiveProfile ?? _appConfig.Profiles.Keys.First();

            ApplyProfile(_currentProfileName);
            UpdateProfileDropdown();
        }

        private void SaveConfig()
        {
            if (!_appConfig.Profiles.ContainsKey(_currentProfileName))
                _appConfig.Profiles[_currentProfileName] = new ProfileData();

            var prof = _appConfig.Profiles[_currentProfileName];
            prof.Axes = _axisConfigs;
            prof.Buttons = _buttonConfigs;
            prof.Hats = _hatConfigs;
            prof.Keys = _keyConfigs;
            _appConfig.ActiveProfile = _currentProfileName;

            string json = JsonSerializer.Serialize(_appConfig);
            API?.StorageSetValue("C2O_AppConfig", json);
        }

        private void ApplyProfile(string profileName)
        {
            if (!_appConfig.Profiles.ContainsKey(profileName)) return;
            var prof = _appConfig.Profiles[profileName];

            if (_txtTargetIp != null) _txtTargetIp.Text = prof.Ip ?? "127.0.0.1";
            if (_txtTargetPort != null) _txtTargetPort.Text = prof.Port ?? "4041";
            if (_txtBaseAddress != null) _txtBaseAddress.Text = prof.BaseAddress ?? "/wheel/input";

            _axisConfigs = prof.Axes ?? new Dictionary<int, AxisConfig>();
            _buttonConfigs = prof.Buttons ?? new Dictionary<int, ButtonConfig>();
            _hatConfigs = prof.Hats ?? new Dictionary<int, HatConfig>();
            _keyConfigs = prof.Keys ?? new Dictionary<int, KeyConfig>();

            RebuildAllDevicesUI();
        }

        private void UpdateProfileDropdown()
        {
            if (_profileDropdown == null) return;

            _isUpdatingProfiles = true;
            _profileDropdown.Items.Clear();
            foreach (var p in _appConfig.Profiles.Keys)
            {
                _profileDropdown.Items.Add(p);
            }
            _profileDropdown.SelectedItem = _currentProfileName;
            _isUpdatingProfiles = false;
        }

        private void OnProfileSelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (_isUpdatingProfiles || _profileDropdown?.SelectedItem == null) return;

            string selected = _profileDropdown.SelectedItem.ToString()!;
            if (selected != _currentProfileName)
            {
                SaveConfig();
                _currentProfileName = selected;
                ApplyProfile(_currentProfileName);
                SaveConfig();
            }
        }

        private void CreateNewProfile(string newName)
        {
            if (string.IsNullOrWhiteSpace(newName) || _appConfig.Profiles.ContainsKey(newName)) return;
            SaveConfig();
            var cloneJson = JsonSerializer.Serialize(_appConfig.Profiles[_currentProfileName]);
            var clone = JsonSerializer.Deserialize<ProfileData>(cloneJson) ?? new ProfileData();
            _appConfig.Profiles[newName] = clone;
            _currentProfileName = newName;

            UpdateProfileDropdown();
            ApplyProfile(newName);
            SaveConfig();
        }

        private async void DeleteCurrentProfile()
        {
            if (_appConfig.Profiles.Count <= 1)
            {
                if (API != null) await API.MessageBox("Cannot Delete", "You cannot delete your only profile.", "OK", "");
                return;
            }
            _appConfig.Profiles.Remove(_currentProfileName);
            _currentProfileName = _appConfig.Profiles.Keys.First();
            UpdateProfileDropdown();
            ApplyProfile(_currentProfileName);
            SaveConfig();
        }

        private async Task ExportProfile()
        {
            try
            {
                SaveConfig();
                var prof = _appConfig.Profiles[_currentProfileName];
                string json = JsonSerializer.Serialize(prof, new JsonSerializerOptions { WriteIndented = true });

                string docsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string c2oFolder = System.IO.Path.Combine(docsPath, "C2O_Profiles");
                Directory.CreateDirectory(c2oFolder);

                string filePath = System.IO.Path.Combine(c2oFolder, $"{_currentProfileName}.json");
                File.WriteAllText(filePath, json);

                if (API != null) await API.MessageBox("Export Successful", $"Profile saved to:\n{filePath}", "OK", "");
            }
            catch (Exception ex) { API?.LogException(ex); }
        }

        private async Task ImportProfiles()
        {
            try
            {
                string docsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string c2oFolder = System.IO.Path.Combine(docsPath, "C2O_Profiles");

                if (!Directory.Exists(c2oFolder))
                {
                    if (API != null) await API.MessageBox("No Profiles Found", $"Please place your .json profile files in:\n{c2oFolder}", "OK", "");
                    return;
                }

                string[] files = Directory.GetFiles(c2oFolder, "*.json");
                int importedCount = 0;

                foreach (var file in files)
                {
                    string json = File.ReadAllText(file);
                    var prof = JsonSerializer.Deserialize<ProfileData>(json);
                    if (prof != null)
                    {
                        string name = System.IO.Path.GetFileNameWithoutExtension(file);
                        _appConfig.Profiles[name] = prof;
                        importedCount++;
                    }
                }

                if (importedCount > 0)
                {
                    SaveConfig();
                    UpdateProfileDropdown();
                    if (API != null) await API.MessageBox("Import Successful", $"Imported {importedCount} profiles successfully.", "OK", "");
                }
            }
            catch (Exception ex) { API?.LogException(ex); }
        }

        private void ToggleStreaming()
        {
            _isStreaming = !_isStreaming;

            if (_isStreaming)
            {
                try
                {
                    string ip = _txtTargetIp?.Text ?? "127.0.0.1";
                    int port = int.TryParse(_txtTargetPort?.Text, out int p) ? p : 4041;
                    _oscSender = new UdpClient(ip, port);
                    LogData($"--- STARTED STREAMING TO {ip}:{port} ---");
                }
                catch (Exception ex)
                {
                    API?.LogException(ex);
                    LogData($"FAILED TO START STREAMING: {ex.Message}");
                    _isStreaming = false;
                }
            }
            else
            {
                _oscSender?.Close();
                _oscSender?.Dispose();
                _oscSender = null;
                LogData("--- STOPPED STREAMING ---");
            }

            if (_btnToggleStream != null)
            {
                _btnToggleStream.Content = _isStreaming ? "Stop Streaming" : "Start Streaming";
                _btnToggleStream.Background = _isStreaming ? Brushes.DarkRed : Brushes.Green;
            }
        }


        // ==========================================
        // HARDWARE POLLING & OSC
        // ==========================================
        private async Task HardwarePollingLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                if (!_isStreaming || _oscSender == null)
                {
                    await Task.Delay(50, token);
                    continue;
                }

                try
                {
                    SDL.SDL_JoystickUpdate();
                    string baseOscPath = _appConfig.Profiles[_currentProfileName].BaseAddress ?? "/wheel/input";

                    foreach (var device in _activeDevices)
                    {
                        // AXES
                        for (int i = 0; i < device.NumAxes; i++)
                        {
                            int globalIdx = device.AxisOffset + i;
                            if (!_axisConfigs.ContainsKey(globalIdx) || !_axisConfigs[globalIdx].IsActive) continue;

                            short rawAxis = SDL.SDL_JoystickGetAxis(device.Joystick, i);
                            float normalizedRawAxis = rawAxis / 32767.0f;
                            float finalVal = GetAxisValue(globalIdx, normalizedRawAxis);

                            if (!_prevAxes.ContainsKey(globalIdx) || Math.Abs(_prevAxes[globalIdx] - finalVal) > 0.001f)
                            {
                                _prevAxes[globalIdx] = finalVal;
                                string addr = string.IsNullOrWhiteSpace(_axisConfigs[globalIdx].CustomAddress) ? baseOscPath : _axisConfigs[globalIdx].CustomAddress;
                                int oscId = _axisConfigs[globalIdx].OscId;

                                var msg = new CoreOSC.OscMessage(new CoreOSC.Address(addr), new object[] { "axis", oscId, finalVal });
                                await _oscSender.SendMessageAsync(msg);
                                LogData($"[{addr}] axis {oscId}: {finalVal:0.000}");
                            }
                        }

                        // BUTTONS
                        for (int i = 0; i < device.NumButtons; i++)
                        {
                            int globalIdx = device.ButtonOffset + i;
                            byte btnState = SDL.SDL_JoystickGetButton(device.Joystick, i);

                            if (!_prevButtons.ContainsKey(globalIdx) || _prevButtons[globalIdx] != btnState)
                            {
                                _prevButtons[globalIdx] = btnState;
                                var cfg = _buttonConfigs.ContainsKey(globalIdx) ? _buttonConfigs[globalIdx] : new ButtonConfig { OscId = globalIdx };

                                string addr = string.IsNullOrWhiteSpace(cfg.CustomAddress) ? baseOscPath : cfg.CustomAddress;

                                var msg = new CoreOSC.OscMessage(new CoreOSC.Address(addr), new object[] { "button", cfg.OscId, (int)btnState });
                                await _oscSender.SendMessageAsync(msg);
                                LogData($"[{addr}] button {cfg.OscId}: {btnState}");
                            }
                        }

                        // HATS
                        for (int i = 0; i < device.NumHats; i++)
                        {
                            int globalIdx = device.HatOffset + i;
                            byte hatState = SDL.SDL_JoystickGetHat(device.Joystick, i);
                            var hatTuple = ParseHatState(hatState);

                            if (!_prevHats.ContainsKey(globalIdx) || _prevHats[globalIdx] != hatTuple)
                            {
                                _prevHats[globalIdx] = hatTuple;
                                var cfg = _hatConfigs.ContainsKey(globalIdx) ? _hatConfigs[globalIdx] : new HatConfig { OscId = globalIdx };
                                string addr = string.IsNullOrWhiteSpace(cfg.CustomAddress) ? baseOscPath : cfg.CustomAddress;

                                var msg = new CoreOSC.OscMessage(new CoreOSC.Address(addr), new object[] { "hat", cfg.OscId, hatTuple.x, hatTuple.y });
                                await _oscSender.SendMessageAsync(msg);
                                LogData($"[{addr}] hat {cfg.OscId}: {hatTuple.x}, {hatTuple.y}");
                            }
                        }
                    }

                    // GLOBAL KEYBOARD
                    foreach (var kvp in _keyConfigs)
                    {
                        int idx = kvp.Key;
                        var cfg = kvp.Value;
                        if (string.IsNullOrWhiteSpace(cfg.KeyName)) continue;

                        if (Enum.TryParse<ConsoleKey>(cfg.KeyName, true, out var consoleKey))
                        {
                            int vKey = (int)consoleKey;
                            bool isPressed = (GetAsyncKeyState(vKey) & 0x8000) != 0;

                            if (!_prevKeys.ContainsKey(idx) || _prevKeys[idx] != isPressed)
                            {
                                _prevKeys[idx] = isPressed;
                                string addr = string.IsNullOrWhiteSpace(cfg.CustomAddress) ? baseOscPath : cfg.CustomAddress;
                                int val = isPressed ? 1 : 0;

                                var msg = new CoreOSC.OscMessage(new CoreOSC.Address(addr), new object[] { "keyboard", cfg.OscId, val });
                                await _oscSender.SendMessageAsync(msg);
                                LogData($"[{addr}] keyboard {cfg.OscId} (Key: {cfg.KeyName}): {val}");
                            }
                        }
                    }

                    await Task.Delay(10, token);
                }
                catch (Exception ex)
                {
                    API?.LogException(ex);
                    await Task.Delay(1000, token);
                }
            }
        }

        private float GetAxisValue(int axisIndex, float rawValue)
        {
            var config = _axisConfigs[axisIndex];
            float val = 0.0f;

            if (Math.Abs(rawValue) >= config.Deadzone)
            {
                float sign = rawValue > 0 ? 1.0f : -1.0f;
                if (config.Deadzone >= 1.0f) val = 0.0f;
                else val = sign * ((Math.Abs(rawValue) - config.Deadzone) / (1.0f - config.Deadzone));
            }

            float valSign = val >= 0 ? 1.0f : -1.0f;
            val = valSign * (float)Math.Pow(Math.Abs(val), config.Curve);
            val *= config.Sensitivity;
            if (config.IsInverted) val = -val;

            val = Math.Max(-1.0f, Math.Min(1.0f, val));

            if (!_axisEmaHistory.ContainsKey(axisIndex)) _axisEmaHistory[axisIndex] = val;
            else
            {
                float alpha = 1.0f - config.Smooth;
                _axisEmaHistory[axisIndex] = (alpha * val) + ((1.0f - alpha) * _axisEmaHistory[axisIndex]);
            }

            return (float)Math.Round(_axisEmaHistory[axisIndex], 3);
        }

        private (int x, int y) ParseHatState(byte hatVal)
        {
            int x = 0, y = 0;
            if ((hatVal & SDL.SDL_HAT_UP) != 0) y = 1;
            else if ((hatVal & SDL.SDL_HAT_DOWN) != 0) y = -1;

            if ((hatVal & SDL.SDL_HAT_RIGHT) != 0) x = 1;
            else if ((hatVal & SDL.SDL_HAT_LEFT) != 0) x = -1;
            return (x, y);
        }

        // ==========================================
        // UI & PREVIEW UPDATES
        // ==========================================
        private async Task UIUpdateLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                API?.DispatchUIAction(() =>
                {
                    foreach (var kvp in _prevAxes)
                        if (_axisPreviewBars.TryGetValue(kvp.Key, out var bar)) bar.Value = kvp.Value;

                    foreach (var kvp in _prevButtons)
                        if (_buttonPreviewDots.TryGetValue(kvp.Key, out var dot)) dot.Fill = kvp.Value == 1 ? Brushes.LimeGreen : Brushes.White;
                });

                await Task.Delay(50, token);
            }
        }

        private void LogData(string message)
        {
            if (!_isLoggingEnabled || _logArea == null) return;
            API?.DispatchUIAction(() =>
            {
                _logArea.Text = message + Environment.NewLine + _logArea.Text;
                if (_logArea.Text.Length > 2000) _logArea.Text = _logArea.Text.Substring(0, 2000);
            });
        }

        private void UpdateWatermarks()
        {
            string baseAddr = _txtBaseAddress?.Text ?? "/wheel/input";
            foreach (var box in _addressWatermarkBoxes)
            {
                box.Watermark = baseAddr;
            }
        }

        // ==========================================
        // AVALONIA UI CONSTRUCTION
        // ==========================================
        private Control BuildSettingsUI()
        {
            _mainUIStack = new StackPanel { Orientation = Orientation.Vertical, Spacing = 15, Margin = new Thickness(15) };
            _addressWatermarkBoxes.Clear();

            // --- 1. PROFILE MANAGEMENT HEADER ---
            var profileGroup = new Expander
            {
                Header = new TextBlock { Text = "Profile Management", Foreground = _labelColor, FontSize = 18, FontWeight = FontWeight.Bold },
                IsExpanded = true,
                Margin = new Thickness(0, 0, 0, 5),
                BorderThickness = new Thickness(0),
                Background = Brushes.Transparent
            };
            var profileWrap = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(15) };

            profileWrap.Children.Add(new TextBlock { Text = "Profile: ", VerticalAlignment = VerticalAlignment.Center, Foreground = _labelColor, FontWeight = FontWeight.Bold, Margin = new Thickness(0, 0, 10, 0) });

            _profileDropdown = new ComboBox { Width = 150, Margin = new Thickness(0, 0, 10, 0) };
            _profileDropdown.SelectionChanged += OnProfileSelectionChanged;
            profileWrap.Children.Add(_profileDropdown);

            var txtNewName = new TextBox { Width = 150, Watermark = "New Profile Name", Margin = new Thickness(0, 0, 10, 0), Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0) };
            profileWrap.Children.Add(txtNewName);

            var btnNew = new Button { Content = "Create", Margin = new Thickness(0, 0, 15, 0) };
            btnNew.Click += (s, e) => { CreateNewProfile(txtNewName.Text); txtNewName.Text = ""; };
            profileWrap.Children.Add(btnNew);

            var btnDelete = new Button { Content = "Delete", Background = Brushes.DarkRed, Foreground = Brushes.White, Margin = new Thickness(0, 0, 20, 0) };
            btnDelete.Click += (s, e) => DeleteCurrentProfile();
            profileWrap.Children.Add(btnDelete);

            var btnImport = new Button { Content = "Import Profiles", Margin = new Thickness(0, 0, 10, 0) };
            btnImport.Click += async (s, e) => await ImportProfiles();
            profileWrap.Children.Add(btnImport);

            var btnExport = new Button { Content = "Export Current", Margin = new Thickness(0, 0, 5, 0) };
            btnExport.Click += async (s, e) => await ExportProfile();
            profileWrap.Children.Add(btnExport);

            profileGroup.Content = profileWrap;
            _mainUIStack.Children.Add(profileGroup);


            // --- 2. OSC TARGETING & TRANSMISSION ---
            var oscGroup = new Expander
            {
                Header = new TextBlock { Text = "OSC Targeting & Listening", Foreground = _labelColor, FontSize = 18, FontWeight = FontWeight.Bold },
                IsExpanded = true,
                Margin = new Thickness(0, 5, 0, 5),
                BorderThickness = new Thickness(0),
                Background = Brushes.Transparent
            };
            var oscStack = new StackPanel { Spacing = 15, Margin = new Thickness(15) };

            var rowIp = new StackPanel { Orientation = Orientation.Horizontal };
            rowIp.Children.Add(new TextBlock { Text = "Target IP:", Width = 150, VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeight.Bold, Foreground = _labelColor });
            _txtTargetIp = new TextBox { Width = 250, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0) };
            _txtTargetIp.TextChanged += (s, e) => { _appConfig.Profiles[_currentProfileName].Ip = _txtTargetIp.Text; SaveConfig(); };
            rowIp.Children.Add(_txtTargetIp);
            oscStack.Children.Add(rowIp);

            var rowPort = new StackPanel { Orientation = Orientation.Horizontal };
            rowPort.Children.Add(new TextBlock { Text = "Target Port (Send):", Width = 150, VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeight.Bold, Foreground = _labelColor });
            _txtTargetPort = new TextBox { Width = 150, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0) };
            _txtTargetPort.TextChanged += (s, e) => { _appConfig.Profiles[_currentProfileName].Port = _txtTargetPort.Text; SaveConfig(); };
            rowPort.Children.Add(_txtTargetPort);
            oscStack.Children.Add(rowPort);

            var rowBaseAddr = new StackPanel { Orientation = Orientation.Horizontal };
            rowBaseAddr.Children.Add(new TextBlock { Text = "Base OSC Address:", Width = 150, VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeight.Bold, Foreground = _labelColor });
            _txtBaseAddress = new TextBox { Width = 250, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0) };
            _txtBaseAddress.TextChanged += (s, e) => {
                _appConfig.Profiles[_currentProfileName].BaseAddress = _txtBaseAddress.Text;
                UpdateWatermarks();
                SaveConfig();
            };
            rowBaseAddr.Children.Add(_txtBaseAddress);
            oscStack.Children.Add(rowBaseAddr);

            _btnToggleStream = new Button { Content = "Start Streaming", Background = Brushes.Green, Foreground = Brushes.White, Margin = new Thickness(0, 10, 0, 0), Width = 180, HorizontalAlignment = HorizontalAlignment.Left };
            _btnToggleStream.Click += (s, e) => ToggleStreaming();
            oscStack.Children.Add(_btnToggleStream);

            oscGroup.Content = oscStack;
            _mainUIStack.Children.Add(oscGroup);


            // --- 3. TOOLTIP INFO EXPANDER ---
            var tooltipExpander = new Expander
            {
                Header = new TextBlock { Text = "Address Configuration & OSC Output Info", FontWeight = FontWeight.Bold, Foreground = _labelColor },
                IsExpanded = false,
                Margin = new Thickness(0, 0, 0, 15),
                BorderThickness = new Thickness(0),
                Background = Brushes.Transparent
            };

            var tooltipContent = new StackPanel { Spacing = 15, Margin = new Thickness(15) };

            // Intro Text
            tooltipContent.Children.Add(new TextBlock
            {
                Text = "If a custom address field is left blank, it automatically defaults to the Base OSC Address defined above (shown as a greyed-out watermark).",
                TextWrapping = TextWrapping.Wrap,
                Foreground = Brushes.LightGray
            });

            // --- OSC STRUCTURE & EXAMPLES BLOCK ---
            var examplesBorder = new Border
            {
                Background = new SolidColorBrush(Color.Parse("#1A1D21")),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(15),
                BorderBrush = new SolidColorBrush(Color.Parse("#3E444D")),
                BorderThickness = new Thickness(1)
            };
            var examplesStack = new StackPanel { Spacing = 10 };

            examplesStack.Children.Add(new TextBlock { Text = "OSC Message Structure", FontWeight = FontWeight.Bold, Foreground = Brushes.White });
            examplesStack.Children.Add(new TextBlock { Text = "When data is sent, the packet contains the target Address followed by its Arguments:\n[InputType (string), OscID (int), Value (float/int)].", TextWrapping = TextWrapping.Wrap, Foreground = Brushes.LightGray });
            examplesStack.Children.Add(new TextBlock { Text = "Examples:", FontWeight = FontWeight.Bold, Foreground = Brushes.White, Margin = new Thickness(0, 10, 0, 0) });

            Control CreateExample(string title, string details, string packet)
            {
                var panel = new StackPanel { Spacing = 2, Margin = new Thickness(10, 0, 0, 10) };
                panel.Children.Add(new TextBlock { Text = $"• {title}", Foreground = _labelColor, FontWeight = FontWeight.Bold });
                panel.Children.Add(new TextBlock { Text = details, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.LightGray, Margin = new Thickness(15, 0, 0, 0) });
                panel.Children.Add(new TextBlock { Text = packet, Foreground = Brushes.LimeGreen, Margin = new Thickness(15, 2, 0, 0) });
                return panel;
            }

            examplesStack.Children.Add(CreateExample("Default Fallback", "If your base Address is set to '/wheel/input', Axis 1's custom address is blank, and the axis is moved to 50%.", "Packet -> Address: /wheel/input   |   Args: [ \"axis\", 1, 0.500 ]"));
            examplesStack.Children.Add(CreateExample("Custom Address", "Button 2's custom address is set to '/custom/eject', and the button is pressed.", "Packet -> Address: /custom/eject  |   Args: [ \"button\", 2, 1 ]"));
            examplesStack.Children.Add(CreateExample("D-Pad / Hat", "Base Address is '/wheel/input', Hat 0's custom address is blank, and it is pushed UP and RIGHT.", "Packet -> Address: /wheel/input   |   Args: [ \"hat\", 0, 1, 1 ]"));

            examplesBorder.Child = examplesStack;
            tooltipContent.Children.Add(examplesBorder);

            // --- OUTGOING SYNTAX BLOCK ---
            var syntaxBorder = new Border
            {
                Background = new SolidColorBrush(Color.Parse("#1A1D21")),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(15),
                BorderBrush = new SolidColorBrush(Color.Parse("#3E444D")),
                BorderThickness = new Thickness(1)
            };
            var syntaxStack = new StackPanel { Spacing = 10 };

            syntaxStack.Children.Add(new TextBlock { Text = "Outgoing Inputs Syntax", FontWeight = FontWeight.Bold, Foreground = Brushes.White });
            syntaxStack.Children.Add(new TextBlock { Text = "From your hardware device -> ML Launcher OSC Plugin -> Massive Loop", TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, FontStyle = FontStyle.Italic });

            var syntaxCode = new TextBlock
            {
                Text = "[Address] 'axis'      [(INT)Mapped ID] [Float Value]\n" +
                       "[Address] 'button'    [(INT)Mapped ID] [Int Value (0/1)]\n" +
                       "[Address] 'hat'       [(INT)Mapped ID] [Int X] [Int Y]\n" +
                       "[Address] 'keyboard'  [(INT)Mapped ID] [Int Value (0/1)]",
                Foreground = _labelColor,
                LineHeight = 22
            };
            syntaxStack.Children.Add(syntaxCode);

            syntaxBorder.Child = syntaxStack;
            tooltipContent.Children.Add(syntaxBorder);

            tooltipContent.Children.Add(new TextBlock
            {
                Text = "You are able to view a live preview of your output towards the bottom of this plugin.",
                TextWrapping = TextWrapping.Wrap,
                Foreground = Brushes.LightGray,
                FontStyle = FontStyle.Italic,
                Margin = new Thickness(0, 5, 0, 0)
            });

            tooltipExpander.Content = tooltipContent;
            _mainUIStack.Children.Add(tooltipExpander);


            // --- 4. DEVICE MANAGEMENT HEADER ---
            var headerStack = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
            _deviceDropdown = new ComboBox { Width = 300 };

            var btnRefresh = new Button { Content = "Refresh Devices" };
            btnRefresh.Click += (s, e) => RefreshDeviceList();

            var btnAdd = new Button { Content = "Add Device", Background = Brushes.Green, Foreground = Brushes.White };
            btnAdd.Click += (s, e) => AddSelectedDevice();

            var btnClear = new Button { Content = "Clear All Devices", Background = Brushes.DarkRed, Foreground = Brushes.White };
            btnClear.Click += (s, e) => ClearDevices();

            headerStack.Children.Add(_deviceDropdown);
            headerStack.Children.Add(btnRefresh);
            headerStack.Children.Add(btnAdd);
            headerStack.Children.Add(btnClear);
            _mainUIStack.Children.Add(headerStack);

            // --- 5. DYNAMIC DEVICE CONTAINER ---
            _dynamicSettingsPanel = new StackPanel { Orientation = Orientation.Vertical, Spacing = 10, Margin = new Thickness(0, 10, 0, 10) };
            _mainUIStack.Children.Add(_dynamicSettingsPanel);

            // --- 6. GLOBAL KEYBOARD CONTAINER ---
            var keyboardGroup = new Expander
            {
                Header = new TextBlock { Text = "Global Keyboard Configuration", Foreground = _labelColor, FontSize = 18, FontWeight = FontWeight.Bold },
                IsExpanded = false,
                Margin = new Thickness(0, 10, 0, 10),
                BorderThickness = new Thickness(0),
                Background = Brushes.Transparent
            };
            _keyboardSettingsPanel = new StackPanel { Spacing = 10, Margin = new Thickness(10) };
            keyboardGroup.Content = _keyboardSettingsPanel;
            _mainUIStack.Children.Add(keyboardGroup);

            // --- 7. TELEMETRY LOG ---
            _mainUIStack.Children.Add(new TextBlock { Text = "Input Logging", FontWeight = FontWeight.Bold, Foreground = _labelColor, Margin = new Thickness(0, 20, 0, 5) });
            _logArea = new TextBox { Height = 150, IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0) };
            _mainUIStack.Children.Add(_logArea);

            return new ScrollViewer { Content = _mainUIStack };
        }

        private void RefreshDeviceList()
        {
            SDL.SDL_JoystickUpdate();
            int count = SDL.SDL_NumJoysticks();
            _deviceDropdown!.Items.Clear();

            if (count == 0) _deviceDropdown.Items.Add("No devices found");
            else
            {
                for (int i = 0; i < count; i++)
                    _deviceDropdown.Items.Add($"[{i}] {SDL.SDL_JoystickNameForIndex(i)}");
            }
            _deviceDropdown.SelectedIndex = 0;
        }

        private void AddSelectedDevice()
        {
            if (_deviceDropdown!.SelectedIndex < 0 || _deviceDropdown.SelectedItem!.ToString()!.Contains("No devices")) return;

            int idx = _deviceDropdown.SelectedIndex;
            if (_activeDevices.Any(d => d.Name == SDL.SDL_JoystickNameForIndex(idx))) return;

            IntPtr joy = SDL.SDL_JoystickOpen(idx);
            if (joy == IntPtr.Zero) return;

            IntPtr haptic = SDL.SDL_HapticOpenFromJoystick(joy);

            var newDevice = new DeviceInfo
            {
                Joystick = joy,
                Haptic = haptic,
                Name = SDL.SDL_JoystickName(joy),
                NumAxes = SDL.SDL_JoystickNumAxes(joy),
                NumButtons = SDL.SDL_JoystickNumButtons(joy),
                NumHats = SDL.SDL_JoystickNumHats(joy),
                AxisOffset = _activeDevices.Sum(d => d.NumAxes),
                ButtonOffset = _activeDevices.Sum(d => d.NumButtons),
                HatOffset = _activeDevices.Sum(d => d.NumHats)
            };

            _activeDevices.Add(newDevice);
            BuildDeviceUI(newDevice);
            SaveConfig();
        }

        private void ClearDevices()
        {
            foreach (var device in _activeDevices)
            {
                if (device.Haptic != IntPtr.Zero) SDL.SDL_HapticClose(device.Haptic);
                if (device.Joystick != IntPtr.Zero) SDL.SDL_JoystickClose(device.Joystick);
            }
            _activeDevices.Clear();
            _dynamicSettingsPanel!.Children.Clear();
            _axisPreviewBars.Clear();
            _buttonPreviewDots.Clear();
            _prevAxes.Clear();
            _prevButtons.Clear();
            _prevHats.Clear();
        }

        private void RebuildAllDevicesUI()
        {
            _addressWatermarkBoxes.Clear();

            if (_dynamicSettingsPanel != null)
            {
                _dynamicSettingsPanel.Children.Clear();
                _axisPreviewBars.Clear();
                _buttonPreviewDots.Clear();

                foreach (var dev in _activeDevices)
                {
                    BuildDeviceUI(dev);
                }
            }

            if (_keyboardSettingsPanel != null)
            {
                BuildKeyboardUI();
            }

            UpdateWatermarks();
        }

        // ==========================================
        // DYNAMIC DEVICE UI GENERATORS
        // ==========================================
        private void BuildDeviceUI(DeviceInfo dev)
        {
            var deviceExpander = new Expander
            {
                Header = new TextBlock { Text = $"Device: {dev.Name}", Foreground = _labelColor, FontSize = 18, FontWeight = FontWeight.Bold },
                IsExpanded = true,
                Margin = new Thickness(0, 10, 0, 0),
                BorderThickness = new Thickness(0),
                Background = Brushes.Transparent
            };
            var mainStack = new StackPanel { Spacing = 10, Margin = new Thickness(10) };

            if (dev.NumAxes > 0)
            {
                var axesGroup = new Expander
                {
                    Header = new TextBlock { Text = "Axis Configuration", Foreground = _labelColor, FontSize = 16, FontWeight = FontWeight.Bold },
                    IsExpanded = true,
                    Margin = new Thickness(0, 5, 0, 0),
                    BorderThickness = new Thickness(0),
                    Background = Brushes.Transparent
                };
                var axesStack = new StackPanel { Spacing = 5, Margin = new Thickness(10) };
                for (int i = 0; i < dev.NumAxes; i++)
                {
                    int globalIdx = dev.AxisOffset + i;
                    if (!_axisConfigs.ContainsKey(globalIdx)) _axisConfigs[globalIdx] = new AxisConfig { OscId = globalIdx, CustomName = $"Axis {globalIdx}" };
                    axesStack.Children.Add(CreateAxisUI(globalIdx));
                }
                axesGroup.Content = axesStack;
                mainStack.Children.Add(axesGroup);
            }

            if (dev.NumButtons > 0)
            {
                var buttonsGroup = new Expander
                {
                    Header = new TextBlock { Text = "Button Mapping", Foreground = _labelColor, FontSize = 16, FontWeight = FontWeight.Bold },
                    IsExpanded = true,
                    Margin = new Thickness(0, 5, 0, 0),
                    BorderThickness = new Thickness(0),
                    Background = Brushes.Transparent
                };
                var btnWrap = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10) };
                for (int i = 0; i < dev.NumButtons; i++)
                {
                    int globalIdx = dev.ButtonOffset + i;
                    if (!_buttonConfigs.ContainsKey(globalIdx)) _buttonConfigs[globalIdx] = new ButtonConfig { OscId = globalIdx, CustomName = $"Btn {globalIdx}" };
                    btnWrap.Children.Add(CreateButtonUI(globalIdx));
                }
                buttonsGroup.Content = btnWrap;
                mainStack.Children.Add(buttonsGroup);
            }

            if (dev.NumHats > 0)
            {
                var hatsGroup = new Expander
                {
                    Header = new TextBlock { Text = "D-Pad / Hat Mapping", Foreground = _labelColor, FontSize = 16, FontWeight = FontWeight.Bold },
                    IsExpanded = true,
                    Margin = new Thickness(0, 5, 0, 0),
                    BorderThickness = new Thickness(0),
                    Background = Brushes.Transparent
                };
                var hatsWrap = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10) };
                for (int i = 0; i < dev.NumHats; i++)
                {
                    int globalIdx = dev.HatOffset + i;
                    if (!_hatConfigs.ContainsKey(globalIdx)) _hatConfigs[globalIdx] = new HatConfig { OscId = globalIdx };
                    hatsWrap.Children.Add(CreateHatUI(globalIdx));
                }
                hatsGroup.Content = hatsWrap;
                mainStack.Children.Add(hatsGroup);
            }

            deviceExpander.Content = mainStack;
            _dynamicSettingsPanel!.Children.Add(deviceExpander);
        }

        private void BuildKeyboardUI()
        {
            _keyboardSettingsPanel!.Children.Clear();
            for (int i = 0; i < 12; i++)
            {
                if (!_keyConfigs.ContainsKey(i)) _keyConfigs[i] = new KeyConfig { OscId = i };
                _keyboardSettingsPanel.Children.Add(CreateKeyUI(i));
            }
        }

        private Control CreateAxisUI(int index)
        {
            string currentBaseAddr = _txtBaseAddress?.Text ?? "/wheel/input";

            var border = new Border { Background = _bgDark, CornerRadius = new CornerRadius(8), Padding = new Thickness(15), Margin = new Thickness(0, 5, 0, 15) };
            var panel = new StackPanel();

            var topRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10, Margin = new Thickness(0, 0, 0, 10) };

            var activeChk = new CheckBox { Content = "Active", IsChecked = _axisConfigs[index].IsActive, Foreground = Brushes.White, VerticalAlignment = VerticalAlignment.Center };
            activeChk.IsCheckedChanged += (s, e) => { _axisConfigs[index].IsActive = activeChk.IsChecked == true; SaveConfig(); };

            var nameBox = new TextBox { Text = _axisConfigs[index].CustomName, Width = 120, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            nameBox.TextChanged += (s, e) => { _axisConfigs[index].CustomName = nameBox.Text; SaveConfig(); };

            var idBox = new TextBox { Text = _axisConfigs[index].OscId.ToString(), Width = 40, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            idBox.TextChanged += (s, e) => { if (int.TryParse(idBox.Text, out int parsed)) { _axisConfigs[index].OscId = parsed; SaveConfig(); } };

            var addrBox = new TextBox { Text = _axisConfigs[index].CustomAddress, Width = 150, Watermark = currentBaseAddr, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            addrBox.TextChanged += (s, e) => { _axisConfigs[index].CustomAddress = addrBox.Text; SaveConfig(); };
            _addressWatermarkBoxes.Add(addrBox);

            var invertChk = new CheckBox { Content = "Invert", IsChecked = _axisConfigs[index].IsInverted, Foreground = Brushes.White, VerticalAlignment = VerticalAlignment.Center };
            invertChk.IsCheckedChanged += (s, e) => { _axisConfigs[index].IsInverted = invertChk.IsChecked == true; SaveConfig(); };

            topRow.Children.Add(activeChk);
            topRow.Children.Add(new TextBlock { Text = "Name:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center });
            topRow.Children.Add(nameBox);
            topRow.Children.Add(new TextBlock { Text = "ID:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeight.Bold });
            topRow.Children.Add(idBox);
            topRow.Children.Add(new TextBlock { Text = "Addr:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeight.Bold });
            topRow.Children.Add(addrBox);
            topRow.Children.Add(invertChk);
            panel.Children.Add(topRow);

            var previewBar = new ProgressBar { Minimum = -1, Maximum = 1, Value = 0, Height = 8, Margin = new Thickness(0, 0, 0, 15), BorderThickness = new Thickness(0) };
            _axisPreviewBars[index] = previewBar;
            panel.Children.Add(previewBar);

            var sliderPanel = new WrapPanel { Orientation = Orientation.Horizontal };
            sliderPanel.Children.Add(CreateInlineSlider("Deadzone", 0.1, 0.5, _axisConfigs[index].Deadzone, v => { _axisConfigs[index].Deadzone = v; SaveConfig(); }));
            sliderPanel.Children.Add(CreateInlineSlider("Sens", 0.1, 5.0, _axisConfigs[index].Sensitivity, v => { _axisConfigs[index].Sensitivity = v; SaveConfig(); }));
            sliderPanel.Children.Add(CreateInlineSlider("Curve", 0.1, 5.0, _axisConfigs[index].Curve, v => { _axisConfigs[index].Curve = v; SaveConfig(); }));
            sliderPanel.Children.Add(CreateInlineSlider("Smooth", 0.0, 0.99, _axisConfigs[index].Smooth, v => { _axisConfigs[index].Smooth = v; SaveConfig(); }));
            panel.Children.Add(sliderPanel);

            border.Child = panel;
            return border;
        }

        private Control CreateButtonUI(int index)
        {
            string currentBaseAddr = _txtBaseAddress?.Text ?? "/wheel/input";

            var border = new Border { Background = _bgDark, CornerRadius = new CornerRadius(6), Padding = new Thickness(10), Margin = new Thickness(5) };
            var panel = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 5, VerticalAlignment = VerticalAlignment.Center };

            var dot = new Ellipse { Width = 12, Height = 12, Fill = Brushes.White, Margin = new Thickness(0, 0, 10, 0) };
            _buttonPreviewDots[index] = dot;

            var nameBox = new TextBox { Text = _buttonConfigs[index].CustomName, Width = 80, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            nameBox.TextChanged += (s, e) => { _buttonConfigs[index].CustomName = nameBox.Text; SaveConfig(); };

            var idBox = new TextBox { Text = _buttonConfigs[index].OscId.ToString(), Width = 35, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            idBox.TextChanged += (s, e) => { if (int.TryParse(idBox.Text, out int p)) { _buttonConfigs[index].OscId = p; SaveConfig(); } };

            var addrBox = new TextBox { Text = _buttonConfigs[index].CustomAddress, Width = 110, Watermark = currentBaseAddr, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            addrBox.TextChanged += (s, e) => { _buttonConfigs[index].CustomAddress = addrBox.Text; SaveConfig(); };
            _addressWatermarkBoxes.Add(addrBox);

            panel.Children.Add(dot);
            panel.Children.Add(nameBox);
            panel.Children.Add(new TextBlock { Text = "ID:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center });
            panel.Children.Add(idBox);
            panel.Children.Add(new TextBlock { Text = "Addr:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center });
            panel.Children.Add(addrBox);

            border.Child = panel;
            return border;
        }

        private Control CreateHatUI(int index)
        {
            string currentBaseAddr = _txtBaseAddress?.Text ?? "/wheel/input";

            var border = new Border { Background = _bgDark, CornerRadius = new CornerRadius(6), Padding = new Thickness(10), Margin = new Thickness(5) };
            var panel = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 5, VerticalAlignment = VerticalAlignment.Center };

            var idBox = new TextBox { Text = _hatConfigs[index].OscId.ToString(), Width = 35, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            idBox.TextChanged += (s, e) => { if (int.TryParse(idBox.Text, out int p)) { _hatConfigs[index].OscId = p; SaveConfig(); } };

            var addrBox = new TextBox { Text = _hatConfigs[index].CustomAddress, Width = 110, Watermark = currentBaseAddr, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            addrBox.TextChanged += (s, e) => { _hatConfigs[index].CustomAddress = addrBox.Text; SaveConfig(); };
            _addressWatermarkBoxes.Add(addrBox);

            panel.Children.Add(new TextBlock { Text = $"Hat {index}  ->  ID:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center });
            panel.Children.Add(idBox);
            panel.Children.Add(new TextBlock { Text = "Addr:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center });
            panel.Children.Add(addrBox);

            border.Child = panel;
            return border;
        }

        private Control CreateKeyUI(int index)
        {
            string currentBaseAddr = _txtBaseAddress?.Text ?? "/wheel/input";

            var border = new Border { Background = _bgDark, CornerRadius = new CornerRadius(6), Padding = new Thickness(10), Margin = new Thickness(5) };
            var panel = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10, VerticalAlignment = VerticalAlignment.Center };

            var keyBox = new TextBox { Text = _keyConfigs[index].KeyName, Width = 80, Watermark = "e.g. A", Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            keyBox.TextChanged += (s, e) => { _keyConfigs[index].KeyName = keyBox.Text; SaveConfig(); };

            var idBox = new TextBox { Text = _keyConfigs[index].OscId.ToString(), Width = 35, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            idBox.TextChanged += (s, e) => { if (int.TryParse(idBox.Text, out int p)) { _keyConfigs[index].OscId = p; SaveConfig(); } };

            var addrBox = new TextBox { Text = _keyConfigs[index].CustomAddress, Width = 150, Watermark = currentBaseAddr, Background = _inputBoxColor, Foreground = Brushes.White, BorderThickness = new Thickness(0), Padding = new Thickness(4) };
            addrBox.TextChanged += (s, e) => { _keyConfigs[index].CustomAddress = addrBox.Text; SaveConfig(); };
            _addressWatermarkBoxes.Add(addrBox);

            panel.Children.Add(new TextBlock { Text = $"Slot {index + 1} Key:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center });
            panel.Children.Add(keyBox);
            panel.Children.Add(new TextBlock { Text = "ID:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center });
            panel.Children.Add(idBox);
            panel.Children.Add(new TextBlock { Text = "Addr:", Foreground = _labelColor, VerticalAlignment = VerticalAlignment.Center });
            panel.Children.Add(addrBox);

            border.Child = panel;
            return border;
        }

        private Control CreateInlineSlider(string label, double min, double max, double val, Action<float> onChanged)
        {
            var p = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 5, Margin = new Thickness(0, 0, 30, 10) };

            var txt = new TextBlock { Text = $"{label}: {val:0.00}", VerticalAlignment = VerticalAlignment.Center, Width = 110, Foreground = _labelColor };

            var slider = new Slider { Minimum = min, Maximum = max, Value = val, Width = 120, TickFrequency = 0.01, IsSnapToTickEnabled = true, VerticalAlignment = VerticalAlignment.Center };

            slider.PropertyChanged += (s, e) => {
                if (e.Property == Slider.ValueProperty && e.NewValue is double newVal)
                {
                    txt.Text = $"{label}: {newVal:0.00}";
                    onChanged((float)newVal);
                }
            };

            p.Children.Add(txt);
            p.Children.Add(slider);
            return p;
        }
    }
}